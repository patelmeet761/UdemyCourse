package com.barosanu;

public class EmailManager {
}
